# Ticket created to populate tests: SA-469
