#### Latest Version

```
1.22.1
```

#### Banner Current

```
* Added functionality for Set, Get, New-JCUser to Search by Email to Manager Field
```

#### Banner Old

```
* New parameter -recoveryemail for Set, Get, New-JCUser
```
